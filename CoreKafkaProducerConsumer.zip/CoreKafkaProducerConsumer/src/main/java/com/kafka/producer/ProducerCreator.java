package com.kafka.producer;

import java.io.IOException;
import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ProducerCreator {

	private static final Logger logger = LoggerFactory.getLogger(ProducerCreator.class);

	public static Producer<Long, String> createProducer(Properties producerProperties) {

		try {
			return new KafkaProducer<>(producerProperties);
		} catch (Exception e) {
			logger.error("exception in createProducer", e);
		}
		return null;
	}

	public static Properties loadProperties(String producerFileName) {
		Properties producerProperties = new Properties();
		try {
			producerProperties.load(ProducerCreator.class.getResourceAsStream("/" + producerFileName));
		} catch (IOException e) {
			logger.error("exception in loadProperties", e);
		}
		return producerProperties;
	}
	
}