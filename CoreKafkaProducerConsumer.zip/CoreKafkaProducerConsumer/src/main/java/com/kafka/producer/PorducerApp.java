package com.kafka.producer;

import java.util.Properties;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PorducerApp {

	private static final Logger logger = LoggerFactory.getLogger(PorducerApp.class);

	public static void main(String[] args) {

		runProducer();

	}

	static void runProducer() {

		Properties producerProperties = ProducerCreator.loadProperties("producer.properties");
		if ("true".equals(producerProperties.getProperty("producer.enable", "false"))) {
			Producer<Long, String> producer = ProducerCreator.createProducer(producerProperties);

			for (int index = 0; index < 10; index++) {

				ProducerRecord<Long, String> record = new ProducerRecord<Long, String>(
						producerProperties.getProperty("topicName"), "This is record " + index);
				try {

					// after calling get() this will wait (asynchronous) till send method returns
					// RecordMetadata object
					RecordMetadata metadata = 
							producer.send(record, new Callback() {

						@Override
						public void onCompletion(RecordMetadata metadata, Exception exception) {

							if (exception != null) {
								// log this error into log file and mark message and Not Send in DB
								logger.error("Error in onCompletion send method", exception);
							} else {
								// will check for the record meta data process it

//								logger.info("Record sent with key " + index + " to partition " + metadata.partition()
//										+ " with offset " + metadata.offset());
							}

						}
					}).get();
					logger.info("Record sent with key " + index + " to partition " + metadata.partition()
							+ " with offset " + metadata.offset());
				} catch (ExecutionException e) {
					logger.error("Error in sending record ExecutionException", e);
				} catch (InterruptedException e) {
					logger.error("Error in sending record InterruptedException", e);
				}
			}
//			producer.flush();
			producer.close();
		} else {
			logger.error("Producer is disable");
		}
	}

}
