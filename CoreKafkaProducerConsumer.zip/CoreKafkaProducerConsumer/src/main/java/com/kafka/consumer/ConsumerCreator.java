package com.kafka.consumer;

import java.io.IOException;
import java.util.Arrays;
import java.util.Properties;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.KafkaConsumer;

import com.kafka.producer.ProducerCreator;

public class ConsumerCreator {
    public static Consumer<Long, String> createConsumer(Properties consumerProperties) {
        try {
			Consumer<Long, String> consumer = new KafkaConsumer<>(consumerProperties);
			consumer.subscribe(Arrays.asList(consumerProperties.getProperty("topicNames").split(",")));
			return consumer;
		} catch (Exception e) {
			System.err.println("exception in createConsumer");
						e.printStackTrace();
		}
        return null;
    }
    
	public static Properties loadProperties(String propertiesFileName) {
		Properties producerProperties = new Properties();
		try {
			producerProperties.load(ProducerCreator.class.getResourceAsStream("/" + propertiesFileName));
		} catch (IOException e) {
			System.err.println("exception in loadProperties");
			e.printStackTrace();
		}
		return producerProperties;
	}
    
}