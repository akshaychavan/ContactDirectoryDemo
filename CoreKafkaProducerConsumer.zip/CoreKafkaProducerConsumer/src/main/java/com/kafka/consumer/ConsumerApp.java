package com.kafka.consumer;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.common.TopicPartition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ConsumerApp {

	private static final Logger logger = LoggerFactory.getLogger(ConsumerApp.class);

	public static void main(String[] args) {

		runConsumer();

	}

	static void runConsumer() {
		Properties consumerProperties = ConsumerCreator.loadProperties("consumer.properties");
		if ("true".equals(consumerProperties.getProperty("consumer.enable", "false"))) {
			Consumer<Long, String> consumer = ConsumerCreator.createConsumer(consumerProperties);
			while (true) {

	            ConsumerRecords<Long, String> records = consumer.poll(Duration.ofMillis(100));

//	            if (records.count() == 0) {
//	    			consumer.close();
//	    			break;
//				}
	            
	            for (ConsumerRecord<Long, String> record : records) {

	                /*
	                Whenever there's a new message in the Kafka topic, we'll get the message in this loop, as
	                the record object.
	                 */

	                /*
	                Getting the message as a string from the record object.
	                 */
	                String message = record.value();

	                /*
	                Logging the received message to the console.
	                 */
	                logger.info("Received message: " + message);

	                /*
	                Once we finish processing a Kafka message, we have to commit the offset so that
	                we don't end up consuming the same message endlessly. By default, the consumer object takes
	                care of this. But to demonstrate how it can be done, we have turned this default behaviour off,
	                instead, we're going to manually commit the offsets.
	                The code for this is below. It's pretty much self explanatory.
	                 */
	                {
	                    Map<TopicPartition, OffsetAndMetadata> commitMessage = new HashMap<>();

	                    commitMessage.put(new TopicPartition(record.topic(), record.partition()),
	                            new OffsetAndMetadata(record.offset() + 1));

	                    consumer.commitSync(commitMessage);

	                    logger.info("Offset committed to Kafka.");
	                }
	            }
	        }
		}
	}

}
