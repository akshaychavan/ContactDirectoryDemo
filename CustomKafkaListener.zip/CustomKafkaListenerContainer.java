package com.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.MessageListenerContainer;
import org.springframework.kafka.support.TopicPartitionInitialOffset;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

@Component
public class CustomKafkaListenerContainer {

	private final Map<String, MessageListenerContainer> listenerContainers =
			new ConcurrentHashMap<String, MessageListenerContainer>();
	
	private static final String GENERATED_ID_PREFIX = "org.springframework.kafka.KafkaListenerEndpointContainer#";
	private final AtomicInteger counter = new AtomicInteger();

	CustomKafkaListener customKafkaListener;

	@Autowired
	ConsumerFactory<String, String> factory;

	@PostConstruct
	public void inIt() {
		
	}
	
	
	
	public void registerListenerContainer(CustomKafkaListener customKafkaListener,
			boolean startImmediately) {
		Assert.notNull(customKafkaListener, "Endpoint must not be null");

		String id = getEndpointId(customKafkaListener);
		Assert.hasText(id, "Endpoint id must not be empty");
		synchronized (this.listenerContainers) {
			Assert.state(!this.listenerContainers.containsKey(id),
					"Another endpoint is already registered with id '" + id + "'");
			ConcurrentMessageListenerContainer<String, String> container = createContainerInstance(customKafkaListener);
			
			if (null != container) {
				container.setupMessageListener(consumeEvent);
				container.setAutoStartup(customKafkaListener.getAutoStartup());
				container.setConcurrency(customKafkaListener.getConcurrency());
				container.setBeanName(id);
				container.getContainerProperties().setClientId(customKafkaListener.getClientIdPrefix());
				this.listenerContainers.put(id, container);
				if (startImmediately) {
					startIfNecessary(container);
				} 
			}
		}
	}
	
	private ConcurrentMessageListenerContainer<String, String> createContainerInstance(CustomKafkaListener customKafkaListener) {
		TopicPartitionInitialOffset[] topicPartitions = resolveTopicPartitions(customKafkaListener);
		if (topicPartitions.length > 0) {
			ContainerProperties properties = new ContainerProperties(topicPartitions);
			return new ConcurrentMessageListenerContainer<String, String>(factory, properties);
		}
		else {
			String[] topics = customKafkaListener.getTopics();
			
			Assert.state(topics.length > 0,
					"At least one 'topics' required in CustomKafkaListener");
			if (topics.length > 0) {
				ContainerProperties properties = new ContainerProperties(topics);
				return new ConcurrentMessageListenerContainer<String, String>(factory, properties);
			}
			else {
				return null;
			}
		}
	}
	
	private void startIfNecessary(MessageListenerContainer listenerContainer) {
		if (listenerContainer.isAutoStartup()) {
			listenerContainer.start();
		}
	}
	
	private String getEndpointId(CustomKafkaListener customKafkaListener) {
		if (StringUtils.hasText(customKafkaListener.getId())) {
			return customKafkaListener.getId();
		}
		else {
			return GENERATED_ID_PREFIX + this.counter.getAndIncrement();
		}
	}

	private TopicPartitionInitialOffset[] resolveTopicPartitions(CustomKafkaListener customKafkaListener) {
		CustomKafkaListener.TopicPartition[] topicPartitions = customKafkaListener.getTopicPartitions();
		List<TopicPartitionInitialOffset> result = new ArrayList<>();
		if (topicPartitions.length > 0) {
			for (CustomKafkaListener.TopicPartition topicPartition : topicPartitions) {
				result.addAll(resolveTopicPartitionsList(topicPartition));
			}
		}
		return result.toArray(new TopicPartitionInitialOffset[result.size()]);
	}

	private List<TopicPartitionInitialOffset> resolveTopicPartitionsList(CustomKafkaListener.TopicPartition topicPartition) {
		String topic = topicPartition.getTopic();
		Assert.hasText(topic, "topic in @TopicPartition must not be empty");
		Integer[] partitions = topicPartition.getPartitions();
		CustomKafkaListener.TopicPartition.PartitionOffset[] partitionOffsets = topicPartition.getPartitionOffsets();
		Assert.state(partitions.length > 0 || partitionOffsets.length > 0,
				"At least one 'partition' or 'partitionOffset' required in @TopicPartition for topic '" + topic + "'");
		List<TopicPartitionInitialOffset> result = new ArrayList<>();
		for (int i = 0; i < partitions.length; i++) {
			result.add(new TopicPartitionInitialOffset(topic, partitions[i]));
		}

		for (CustomKafkaListener.TopicPartition.PartitionOffset partitionOffset : partitionOffsets) {
			TopicPartitionInitialOffset topicPartitionOffset =
					new TopicPartitionInitialOffset(topic,
							partitionOffset.getPartition(),
							partitionOffset.getInitialOffset(),
							partitionOffset.getRelativeToCurrent());
			if (!result.contains(topicPartitionOffset)) {
				result.add(topicPartitionOffset);
			}
			else {
				throw new IllegalArgumentException(
						String.format("@TopicPartition can't have the same partition configuration twice: [%s]",
								topicPartitionOffset));
			}
		}
		return result;
	}
	
}