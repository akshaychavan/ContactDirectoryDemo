//package com.contactsunny.poc.SimpleKafkaProducer;
//public class DoRunCode {
//
//	@MyAnnotation("doh")
//	public static boolean validate(String s) {
//		System.out.println("Validating " + s);
//		return true;
//	}
//
//	public static boolean validate2(String s) {
//		System.out.println("Validating2 " + s);
//		return true;
//	}
//
//	public static void main(String[] args) throws Exception {
//
//		validate("hello");
//		validate2("cheers");
//
//	}
//
////	@Bean
////	public MyAspectClass MyAspectClass() {
////		return new MyAspectClass();
////	}
//}
